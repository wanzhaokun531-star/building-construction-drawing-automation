"""External Python worker: platform-independent; the web host never executes CAD/WPS."""
import json
import os
import signal
import socket
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit
import requests
from .engine import review
from .pdf import sha256,atomic_json
from .reports import generate_reports

def run_worker(once=False):
    base=os.environ['DRAWING_REVIEW_BASE_URL'].rstrip('/')
    token=os.environ['DRAWING_REVIEW_WORKER_TOKEN']
    profiles=json.loads(Path(os.environ['DRAWING_REVIEW_PROFILES']).read_text('utf8'))
    storage=Path(os.getenv('DRAWING_REVIEW_DATA','./drawing-review-data')).resolve();storage.mkdir(parents=True,exist_ok=True)
    stop=threading.Event();active_cancel=[None]
    def shutdown(*_):
        stop.set()
        if active_cancel[0]:active_cancel[0].touch()
    signal.signal(signal.SIGINT,shutdown);signal.signal(signal.SIGTERM,shutdown)
    sessions=threading.local()
    prefix='/api/internal/drawing-review-worker'
    def request(method,path,**kwargs):
        url=base+path if path.startswith('/') else path
        endpoint=urlsplit(url);origin=urlsplit(base)
        if (endpoint.scheme,endpoint.netloc)!=(origin.scheme,origin.netloc) or endpoint.username or endpoint.password:raise ValueError('Worker禁止向其他来源发送凭据')
        if not hasattr(sessions,'http'):
            sessions.http=requests.Session();sessions.http.headers['Authorization']='Bearer '+token
        r=sessions.http.request(method,url,timeout=(15,90),allow_redirects=False,**kwargs)
        if not r.ok:raise RuntimeError(f'Worker HTTP {r.status_code}')
        return r
    while not stop.is_set():
        task=None;heartbeat_stop=threading.Event();thread=None
        try:
            task=request('POST',prefix+'/claim',json={'workerId':socket.gethostname()}).json().get('data')
            if not task:
                if once:return
                stop.wait(5);continue
            runid=task['runId'];lease=task['leaseToken'];job=task['job']
            # Server generated UUIDs only; never derive filesystem paths from supplied filenames.
            import re
            if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',runid):raise ValueError('任务标识无效')
            out=storage/runid;out.mkdir(exist_ok=True);cancel=out/'CANCEL'
            active_cancel[0]=cancel
            if cancel.exists():cancel.unlink()
            progress_state={}
            def heartbeat():
                while not heartbeat_stop.wait(30):
                    try:request('POST',prefix+'/'+runid,json={'action':'heartbeat','leaseToken':lease,'progress':json.dumps(progress_state,ensure_ascii=False)})
                    except Exception:cancel.touch();return
            thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
            files=[]
            for i,f in enumerate(job['files']):
                if cancel.exists():break
                path=out/f'input-{i:04d}.pdf'
                if not path.exists() or sha256(path)!=f['sha256']:
                    download=f['downloadUrl']
                    params=None if 'leaseToken=' in download else {'leaseToken':lease}
                    r=request('GET',download,params=params)
                    path.write_bytes(r.content)
                if sha256(path)!=f['sha256']:raise ValueError('PDF哈希不匹配')
                files.append({'id':f['id'],'filename':f['filename'],'path':str(path)})
            if cancel.exists():
                if once:return
                continue
            name=job.get('modelProfile') or 'default';model=dict(profiles[name]) if name in profiles else None
            if model and model.get('apiKeyEnv'):model['apiKey']=os.getenv(model['apiKeyEnv'],'')
            budget=job.get('budget') or {}
            limit=budget.get('maxTokens') if isinstance(budget,dict) else budget
            result=review(files,out,job.get('selectedChecks'),job.get('project'),model,limit,
                          model.pop('norms',[]) if model else [],cache_dir=storage/'cache',budget_cost=budget.get('maxCost') if isinstance(budget,dict) else None,progress=lambda value:progress_state.update(value))
            if job.get('sourceWarnings'):
                result['warnings']=[*job['sourceWarnings'],*result['warnings']]
                if result['status']=='completed':result['status']='needs_review'
                atomic_json(out/'result.json',result)
            if cancel.exists():
                if once:return
                continue
            generate_reports(result,out)
            atomic_json(out/'coverage.json',{'fingerprint':result['fingerprint'],'checks':result['checks'],'files':result['files'],'warnings':result['warnings']})
            for path in [out/'report-detail.pdf',out/'report-brief.pdf',out/'coverage.json',*sorted((out/'evidence').glob('*.png'))]:
                if not path.is_file():continue
                with path.open('rb') as stream:
                    request('PUT',prefix+'/'+runid+'/artifacts',params={'leaseToken':lease,'name':path.relative_to(out).as_posix()},data=stream,
                            headers={'Content-Type':{'.pdf':'application/pdf','.png':'image/png','.json':'application/json'}[path.suffix]})
            request('POST',prefix+'/'+runid,json={'action':'complete','leaseToken':lease,'result':result})
            print(json.dumps({'runId':runid,'status':result['status']},ensure_ascii=False),flush=True)
        except Exception as e:
            # Do not log endpoint response bodies or secrets.
            print(json.dumps({'status':'error','error':str(e)[:300]},ensure_ascii=False),flush=True)
            if task:
                try:request('POST',prefix+'/'+task['runId'],json={'action':'fail','leaseToken':task['leaseToken'],'error':str(e)[:300]})
                except Exception:pass
            if not once:stop.wait(10)
        finally:
            heartbeat_stop.set()
            if thread:thread.join(timeout=2)
            active_cancel[0]=None
        if once:return
