"""Deterministic arithmetic; never infer the applicability of a structural check."""
import math
import re

def steel_area(text):
    value = text.replace('%%132', 'Φ').replace('%%c', 'Φ').replace('φ', 'Φ').replace('∅', 'Φ')
    parts = value.split('+')
    total = 0.0
    for part in parts:
        m = re.fullmatch(r'\s*(\d+)\s*Φ\s*(\d+(?:\.\d+)?)\s*', part)
        if not m:
            raise ValueError('只接受明确的根数及直径，如3Φ16或2Φ16+1Φ14；原位适用范围须另核')
        n, d = int(m[1]), float(m[2])
        if n <= 0 or not 3 <= d <= 80: raise ValueError('钢筋参数超出可计算范围')
        total += n * math.pi * d*d / 4
    return total

def distributed_area(diameter_mm, spacing_mm, legs=1):
    if any(not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or v<=0 for v in (diameter_mm,spacing_mm,legs)) or int(legs)!=legs:raise ValueError('直径和间距必须为有限正数，肢数须为正整数')
    return legs * math.pi * diameter_mm**2 / 4 * 1000 / spacing_mm

def dead_load(layers):
    """Each layer uses metres and kN/m³; inputs must have a cited or assumed basis."""
    if not layers or any(not all(isinstance(l.get(k),(int,float)) and not isinstance(l.get(k),bool) and math.isfinite(l[k]) for k in ('thickness_m','density_kn_m3')) or l['thickness_m'] < 0 or l['density_kn_m3'] <= 0 or not l.get('basis') for l in layers):
        raise ValueError('每层需提供厚度m、容重kN/m³及依据')
    return sum(l['thickness_m'] * l['density_kn_m3'] for l in layers)

def compare_steel(actual_text, required_mm2, *, same_section, same_direction, correspondence_verified):
    if not isinstance(required_mm2,(int,float)) or isinstance(required_mm2,bool) or not math.isfinite(required_mm2) or required_mm2<0:raise ValueError('需筋必须为有限非负数，单位mm²')
    actual = steel_area(actual_text)
    valid = same_section and same_direction and correspondence_verified
    return {'actual_mm2': actual, 'required_mm2': required_mm2, 'difference_mm2': actual-required_mm2,
            'status': '疑点' if valid and actual < required_mm2 else '面积对照未见不足' if valid else '资料不足',
            'limitation': '不替代锚固、延伸、最小配筋、受剪及正常使用验算'}
