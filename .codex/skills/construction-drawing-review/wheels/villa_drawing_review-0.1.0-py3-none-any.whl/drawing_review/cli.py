import argparse
import json
import os
from pathlib import Path
from .engine import review,CHECKS
from .pdf import extract,atomic_json

def main():
    parser=argparse.ArgumentParser(description='施工图PDF校审：图文证据、覆盖台账及断点恢复')
    subs=parser.add_subparsers(dest='command',required=True)
    subs.add_parser('checks')
    q=subs.add_parser('extract');q.add_argument('pdf');q.add_argument('--output',required=True);q.add_argument('--no-ocr',action='store_true')
    q=subs.add_parser('review');q.add_argument('folder');q.add_argument('--output',required=True);q.add_argument('--checks',nargs='+');q.add_argument('--config');q.add_argument('--budget-tokens',type=int);q.add_argument('--budget-cost',type=float);q.add_argument('--cache-dir');q.add_argument('--reports',action='store_true')
    q=subs.add_parser('report');q.add_argument('result')
    q=subs.add_parser('worker');q.add_argument('--once',action='store_true')
    args=parser.parse_args()
    if args.command=='checks':print(json.dumps(CHECKS,ensure_ascii=False,indent=2));return
    if args.command=='extract':
        r=extract(args.pdf,Path(args.output)/'cache',not args.no_ocr);atomic_json(Path(args.output)/'extracted.json',r);print(json.dumps({'pages':r['pageCount'],'warnings':r['warnings']},ensure_ascii=False));return
    if args.command=='report':
        from .reports import generate_reports
        p=Path(args.result);print(json.dumps(generate_reports(json.loads(p.read_text('utf8')),p.parent),ensure_ascii=False));return
    if args.command=='worker':
        from .worker import run_worker
        run_worker(args.once);return
    config=json.loads(Path(args.config).read_text('utf8')) if args.config else {}
    model=config.get('model')
    if model and model.get('apiKeyEnv'):model['apiKey']=os.getenv(model['apiKeyEnv'],'')
    files=[{'path':str(p)} for p in sorted(Path(args.folder).rglob('*')) if p.is_file() and p.suffix.lower()=='.pdf' and not Path(args.output).resolve() in p.resolve().parents]
    if not files:parser.error('输入目录内没有PDF')
    result=review(files,args.output,args.checks,config.get('project'),model,args.budget_tokens,config.get('norms'),progress=lambda p:print(json.dumps(p,ensure_ascii=False),flush=True),cache_dir=args.cache_dir,budget_cost=args.budget_cost)
    if args.reports:
        from .reports import generate_reports
        generate_reports(result,args.output)
    print(json.dumps({'status':result['status'],'checks':len(result['checks']),'issues':len(result['issues']),'result':str(Path(args.output)/'result.json')},ensure_ascii=False))

if __name__=='__main__':main()
