"""Spatially referenced index candidates, never automatic member correspondence."""
import re

PATTERNS = {
    'drawingNumbers': re.compile(r'(?:建施|结施|水施|电施|暖施|建总施|结总施)\s*[-－—]?\s*\d+(?:\s*[-－]\s*\d+)?', re.I),
    'floors': re.compile(r'地下\s*[一二三四五六七八九十\d]+\s*[层樓楼]|[一二三四五六七八九十\d]+\s*[层樓楼]|首层|屋面|屋顶|闷顶|阁楼|基础层|\b(?:B?\d{1,2}F|ROOF|BASEMENT)\b', re.I),
    'members': re.compile(r'(?<![A-Za-z0-9])(?:WKL|KL|KZ|GZ|L|Z|B|ZH|CTJ?|AT|BT|DT|JZ|LL|XL)\s*[-－]?\s*\d+[A-Za-z]?(?:\s*\([^)]{1,12}\))?(?![A-Za-z0-9])', re.I),
}


def candidate_indexes(words, tables, page):
    result = {key: [] for key in PATTERNS}
    result.update({'tables': tables, 'policy': 'candidate-only', 'matchVerified': False,
        'limitation': '同编号、同图号或同楼层文本仅为对应候选；须结合轴线、位置、截面和原位标注核实'})
    ordered = sorted(words, key=lambda w: (w['top'], w['x0']))
    runs = []
    for word in ordered:
        for run in reversed(runs[-12:]):
            last = run[-1]
            height = max(last['bottom'] - last['top'], word['bottom'] - word['top'], 1)
            if abs(word['top'] - last['top']) <= height * .4 and -.1 <= word['x0'] - last['x1'] <= max(15, height * 1.5):
                run.append(word)
                break
        else:
            runs.append([word])
    seen = {key: set() for key in PATTERNS}
    for run in runs:
        text, spans = '', []
        for word in run:
            if text:
                text += ' '
            start = len(text)
            text += word['text']
            spans.append((start, len(text), word))
        for key, pattern in PATTERNS.items():
            for match in pattern.finditer(text):
                group = [w for start, end, w in spans if start < match.end() and end > match.start()]
                ids = tuple(w['id'] for w in group)
                identity = (match.group(), ids)
                if identity in seen[key]:
                    continue
                seen[key].add(identity)
                result[key].append({'value': match.group(), 'page': page, 'wordIds': list(ids),
                    'bbox': [min(w['x0'] for w in group), min(w['top'] for w in group),
                             max(w['x1'] for w in group), max(w['bottom'] for w in group)],
                    'status': 'candidate', 'matchVerified': False})
    return result
