import html
import json
import os
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,PageBreak,KeepTogether

def font_name():
    for candidate in [os.getenv('DRAWING_REVIEW_FONT',''),r'C:\Windows\Fonts\msyh.ttc','/System/Library/Fonts/Supplemental/Arial Unicode.ttf']:
        if candidate and Path(candidate).is_file():
            try:pdfmetrics.registerFont(TTFont('ReviewCN',candidate));return 'ReviewCN'
            except Exception:pass
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'));return 'STSong-Light'

def generate_reports(result,output):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);font=font_name()
    base=ParagraphStyle('text',fontName=font,fontSize=10,leading=15,wordWrap='CJK',spaceAfter=7)
    title=ParagraphStyle('title',parent=base,fontSize=19,leading=27,spaceAfter=12,textColor=colors.HexColor('#163d60'))
    heading=ParagraphStyle('heading',parent=base,fontSize=13,leading=19,spaceBefore=9,spaceAfter=7,textColor=colors.HexColor('#163d60'))
    def p(text,style=base):return Paragraph(html.escape(str(text)).replace('\n','<br/>'),style)
    evidence={e['id']:e for e in result['evidence']}
    paths=[]
    for brief in (False,True):
        path=out/('report-brief.pdf' if brief else 'report-detail.pdf')
        doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=35,leftMargin=35,topMargin=35,bottomMargin=36)
        state={'needs_review':'待补证或复核','completed':'本次运行完成','paused':'已暂停','cancelled':'已取消'}.get(result['status'],result['status'])
        story=[p((result.get('project',{}).get('name') or '施工图项目')+' · '+('校审整改清单' if brief else '施工图校审图文报告'),title),p(result['limitation']),p(result.get('coverageLimitation','')),p('任务状态：'+state+'；依据文件版本：'+result['fingerprint'][:16])]
        selected=[c for c in result['checks'] if c['status']!='未选择']
        story.append(p(f"所选检查项{len(selected)}项；问题{len(result['issues'])}项。资料不足{sum(c['status']=='资料不足' for c in selected)}项。"))
        for issue in result['issues']:
            if not brief:story.append(PageBreak())
            story += [p(issue['title']+' ['+issue['status']+']',heading),p(issue['opinion'])]
            if issue.get('calculation'):story.append(p('计算核对：'+issue['calculation']))
            for eid in issue['evidenceIds']:
                e=evidence[eid];image_path=out/e['image']
                if image_path.is_file():
                    im=Image(str(image_path));im._restrictSize(A4[0]-70,125 if brief else 255)
                    story.append(KeepTogether([p(issue['title']+'：'+issue['opinion'][:180]),p(f"证据：{e['filename']} 第{e['page']}页；区域 {e['bbox']}"),im,Spacer(1,9)]))
            for nid in issue.get('normIds',[]):
                n=next((n for n in result.get('norms',[]) if n['id']==nid),None)
                if n:story.append(p(f"依据：{n['version']} {n['clause']}；来源 {n['source']}"))
        pending=[c for c in selected if c['status']=='资料不足']
        if pending:story.append(p('待补证或继续审核的项目',heading))
        for c in pending:story.append(p(c['title']+'：'+c['summary']))
        if not brief:
            story.extend([PageBreak(),p('全量检查覆盖台账',title)])
            for c in result['checks']:
                story.append(p(f"{c['discipline']} / {c['title']}：{c['status']}；区域{c['reviewedRegions']}/{c['totalRegions']}"))
                if c['status']!='未选择':story.append(p(c['summary']))
            story.append(p('资料版本及提取记录',heading))
            for f in result['files']:story.append(p(f"{f['filename']} / {f['pageCount']}页 / SHA256 {f['sha256']}"))
            for warning in result.get('warnings',[]):story.append(p(warning))
            story.append(p('模型用量：'+json.dumps(result['usage'],ensure_ascii=False)))
        def footer(canvas,doc):
            canvas.setFont(font,8);canvas.drawString(35,20,'施工图辅助校审 · 意见以对应版本和证据为准');canvas.drawRightString(A4[0]-35,20,str(doc.page))
        doc.build(story,onFirstPage=footer,onLaterPages=footer);paths.append(str(path))
    return paths
