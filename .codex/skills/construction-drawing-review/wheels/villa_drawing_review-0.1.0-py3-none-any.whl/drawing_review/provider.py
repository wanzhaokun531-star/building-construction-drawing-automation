import json
import re
import math
import requests
from urllib.parse import urlsplit

class ModelResponseError(RuntimeError):
    """A charged response can be unusable; preserve its measured usage."""
    def __init__(self, message, usage):
        super().__init__(message)
        self.usage = usage

class ModelClient:
    def __init__(self,config):
        self.config=config
        if not config.get('baseUrl') or not config.get('model'):raise ValueError('需配置模型及接口地址')
        endpoint=urlsplit(config['baseUrl'])
        if endpoint.scheme not in ('http','https') or not endpoint.hostname or endpoint.username or endpoint.password:
            raise ValueError('模型接口须为无内嵌凭据的HTTP(S)地址')
        self.url=config['baseUrl'].rstrip('/')+'/chat/completions'
    def complete(self,messages):
        headers={'Content-Type':'application/json'}
        if self.config.get('apiKey'):headers['Authorization']='Bearer '+self.config['apiKey']
        body={'model':self.config['model'],'messages':messages,'max_tokens':self.config.get('maxOutputTokens',3000)}
        if self.config.get('jsonMode',False):body['response_format']={'type':'json_object'}
        r=requests.post(self.url,headers=headers,json=body,timeout=(15,180))
        if not r.ok:raise RuntimeError(f'模型接口HTTP {r.status_code}；请核对配置或配额')
        data=r.json()
        usage=data.get('usage') or {}
        def count(v):return v if isinstance(v,int) and not isinstance(v,bool) and v>=0 else None
        measured={'inputTokens':count(usage.get('prompt_tokens')),'outputTokens':count(usage.get('completion_tokens')),
            'cachedInputTokens':count((usage.get('prompt_tokens_details') or {}).get('cached_tokens')),'providerModel':data.get('model',self.config['model'])}
        prices=self.config.get('pricing') or {}
        measured['cost']=None;measured['currency']=prices.get('currency');measured['pricingSnapshot']=prices
        valid_price=lambda v:isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0
        if measured['inputTokens'] is not None and measured['outputTokens'] is not None and all(valid_price(prices.get(k)) for k in ('inputPerMillion','outputPerMillion')) and valid_price(prices.get('cachedInputPerMillion',prices['inputPerMillion'])):
            cached=min(measured['cachedInputTokens'] or 0,measured['inputTokens'])
            measured['cost']=((measured['inputTokens']-cached)*prices['inputPerMillion']+cached*prices.get('cachedInputPerMillion',prices['inputPerMillion'])+measured['outputTokens']*prices['outputPerMillion'])/1e6
        try:
            content=data['choices'][0]['message']['content']
            if not isinstance(content,str):raise ValueError('non-text response')
            content=re.sub(r'^```(?:json)?\s*|\s*```$','',content.strip())
            result=json.loads(content)
        except (KeyError,IndexError,TypeError,ValueError) as e:
            raise ModelResponseError('模型响应不是有效审图JSON；已保存接口用量',measured) from e
        return result,measured
