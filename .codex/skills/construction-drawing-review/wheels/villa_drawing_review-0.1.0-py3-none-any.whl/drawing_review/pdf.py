"""Text-independent PDF evidence coverage in visible-page top-left coordinates."""
import hashlib
import json
import math
import re
from pathlib import Path
import pdfplumber
import pypdfium2 as pdfium
from . import __version__
from .indexing import candidate_indexes

EXTRACTOR_VERSION = "spatial-tiles-3"
TILE_SIZE_PT = 900.0
TILE_OVERLAP_PT = 48.0
MAX_RENDER_PIXELS = 4_000_000
MAX_RENDER_EDGE = 4096
MAX_TABLE_EDGES_PER_TILE = 1500
MAX_TABLE_CANDIDATES_PER_TILE = 20


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf8')
    temporary.replace(path)


def spatial_tiles(width, height, size=TILE_SIZE_PT, overlap=TILE_OVERLAP_PT):
    """Cover every point, including drawing-only areas and thin end strips."""
    if not all(math.isfinite(v) for v in (width, height, size, overlap)):
        raise ValueError('页面和图块尺寸必须为有限数值')
    if min(width, height, size) <= 0 or not 0 <= overlap < size:
        raise ValueError('页面/图块尺寸无效，重叠须小于图块尺寸')
    def starts(length):
        value = 0.0
        while True:
            yield value
            if value + size >= length:
                return
            value += size - overlap
    return [[x, y, min(width, x + size), min(height, y + size)]
            for y in starts(height) for x in starts(width)]


def render(path, page, bbox=None, scale=1.5, *, max_pixels=None, max_edge=None):
    """Render the crop directly with a pixel budget; return PIL.Image as before.

    image.info['renderMetadata'] records downsampling and the exact raster origin.
    """
    max_pixels = MAX_RENDER_PIXELS if max_pixels is None else max_pixels
    max_edge = MAX_RENDER_EDGE if max_edge is None else max_edge
    if not isinstance(page, int) or page < 1:
        raise ValueError('PDF页码从1开始')
    if not math.isfinite(scale) or scale <= 0 or max_pixels < 1 or max_edge < 1:
        raise ValueError('渲染比例和像素上限必须为正数')
    with pdfium.PdfDocument(str(path)) as doc:
        if page > len(doc):
            raise ValueError('PDF页码超出范围')
        p = doc[page - 1]
        try:
            width, height = p.get_size()
            requested = [0.0, 0.0, width, height] if bbox is None else list(bbox)
            if len(requested) != 4 or not all(math.isfinite(v) for v in requested):
                raise ValueError('证据区域须为四个有限坐标')
            x0, y0 = max(0.0, requested[0]), max(0.0, requested[1])
            x1, y1 = min(width, requested[2]), min(height, requested[3])
            if x1 <= x0 or y1 <= y0:
                raise ValueError('证据区域不与PDF可见页面相交')
            effective = min(scale, math.sqrt(max_pixels / ((x1 - x0) * (y1 - y0))),
                            max_edge / max(x1 - x0, y1 - y0))
            crop = (x0, height - y1, width - x1, y0)
            def dimensions(s):
                return (math.ceil(width * s) - math.ceil(crop[0] * s) - math.ceil(crop[2] * s),
                        math.ceil(height * s) - math.ceil(crop[1] * s) - math.ceil(crop[3] * s))
            for _ in range(32):
                pixel_width, pixel_height = dimensions(effective)
                if min(pixel_width, pixel_height) < 1:
                    raise ValueError('该区域在像素上限内不足1像素，请缩小证据区域')
                if pixel_width * pixel_height <= max_pixels and max(pixel_width, pixel_height) <= max_edge:
                    break
                effective *= .999
            else:
                raise ValueError('无法在像素上限内渲染此区域')
            if max(width, height) * effective > 2_000_000_000:
                raise ValueError('PDF坐标超过安全渲染范围')
            bitmap = p.render(scale=effective, crop=crop, limit_image_cache=True)
            try:
                image = bitmap.to_pil().copy()
            finally:
                bitmap.close()
            ox, oy = math.ceil(x0 * effective) / effective, math.ceil(y0 * effective) / effective
            downsampled = effective < scale * (1 - 1e-9)
            image.info['renderMetadata'] = {
                'coordinateSystem': 'visible-page-top-left-pt', 'page': page,
                'requestedBbox': requested, 'clippedBbox': [x0, y0, x1, y1],
                'renderedBbox': [ox, oy, ox + image.width / effective, oy + image.height / effective],
                'requestedScale': scale, 'effectiveScale': effective,
                'pixelWidth': image.width, 'pixelHeight': image.height,
                'maxPixels': max_pixels, 'maxEdge': max_edge, 'downsampled': downsampled,
                'limitations': ['受像素上限限制已降采样；细小尺寸和钢筋符号需较小区域复核'] if downsampled else [],
            }
            return image
        finally:
            p.close()


def _intersects(a, b):
    return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]


def _word_box(word):
    return [word['x0'], word['top'], word['x1'], word['bottom']]


def _suspect_word(text):
    return bool(re.search(r'\(cid:\d+\)|\ufffd|[\x00-\x08\x0b\x0c\x0e-\x1f\ue000-\uf8ff]', text))


def _ocr_region(path, page, bbox):
    import pytesseract
    image = render(path, page, bbox, scale=2)
    metadata = image.info['renderMetadata']
    try:
        data = pytesseract.image_to_data(image, lang='chi_sim+eng',
            output_type=pytesseract.Output.DICT, timeout=90)
    finally:
        image.close()
    scale = metadata['effectiveScale']
    ox, oy = metadata['renderedBbox'][:2]
    words = []
    for index, text in enumerate(data['text']):
        if text.strip():
            x, y, width, height = [data[key][index] / scale for key in ('left', 'top', 'width', 'height')]
            words.append({'text': text, 'x0': ox + x, 'top': oy + y,
                'x1': ox + x + width, 'bottom': oy + y + height,
                'confidence': float(data['conf'][index]), 'method': 'ocr', 'quality': 'requires-verification'})
    return words, metadata


def _normalize_box(box, origin, sx, sy):
    return [(box[0] - origin[0]) * sx, (box[1] - origin[1]) * sy,
            (box[2] - origin[0]) * sx, (box[3] - origin[1]) * sy]


def _tables(p, bbox, origin, sx, sy, region_id):
    """Bound line matching before attempting local, unverified table candidates."""
    absolute = (bbox[0] / sx + origin[0], bbox[1] / sy + origin[1],
                bbox[2] / sx + origin[0], bbox[3] / sy + origin[1])
    crop = p.crop(absolute, strict=False)
    warnings, tables = [], []
    if len(crop.edges) > MAX_TABLE_EDGES_PER_TILE:
        return [], ['该区域线段过多，自动表格候选识别未执行；须图像核对'], 'deferred'
    try:
        found = crop.find_tables()
        for index, table in enumerate(found[:MAX_TABLE_CANDIDATES_PER_TILE]):
            tables.append({'id': f'{region_id}:table{index}',
                'bbox': _normalize_box(table.bbox, origin, sx, sy),
                'cells': [[str(cell or '') for cell in row] for row in table.extract()],
                'status': 'candidate', 'matchVerified': False})
        if len(found) > MAX_TABLE_CANDIDATES_PER_TILE:
            warnings.append('表格候选超过区域上限，仅保留前20个；不能认定全部表格已识别')
        return tables, warnings, 'candidate-only'
    except Exception as error:
        return [], ['自动表格候选识别失败：' + type(error).__name__], 'failed'


def extract(path, cache, ocr=True):
    path = Path(path)
    digest = sha256(path)
    key = f'{digest}-{__version__}-{EXTRACTOR_VERSION}-ocr{int(ocr)}'
    target = Path(cache) / (key + '.json')
    if target.exists():
        data = json.loads(target.read_text('utf8'))
        data['cacheHit'] = True
        return data
    pages, warnings = [], []
    with pdfplumber.open(path) as doc, pdfium.PdfDocument(str(path)) as native:
        for index, p in enumerate(doc.pages):
            visible = native[index]
            try:
                width, height = visible.get_size()
            finally:
                visible.close()
            box = [max(p.mediabox[0], p.cropbox[0]), max(p.mediabox[1], p.cropbox[1]),
                   min(p.mediabox[2], p.cropbox[2]), min(p.mediabox[3], p.cropbox[3])]
            if box[2] <= box[0] or box[3] <= box[1]:
                raise ValueError(f'第{index + 1}页可见页面边界无效')
            sx, sy = width / (box[2] - box[0]), height / (box[3] - box[1])
            raw_words = p.extract_words(x_tolerance=2, y_tolerance=3) or []
            words, page_warnings = [], []
            if abs(sx - 1) > .001 or abs(sy - 1) > .001:
                page_warnings.append('可见框与文字坐标单位不同，已归一化；需核验定位，不能用于实物尺寸测量')
            for raw in raw_words:
                wb = _word_box(raw)
                if not _intersects(wb, box):
                    continue
                x0, y0, x1, y1 = _normalize_box(wb, box, sx, sy)
                text = str(raw.get('text', ''))
                words.append({**raw, 'x0': max(0, x0), 'top': max(0, y0),
                    'x1': min(width, x1), 'bottom': min(height, y1), 'method': 'native',
                    'quality': 'suspect' if _suspect_word(text) else 'native'})
            regions, page_tables = [], []
            for tile_index, bbox in enumerate(spatial_tiles(width, height)):
                rid = f'{digest[:16]}:p{index + 1}:r{tile_index}'
                group = [w for w in words if _intersects(_word_box(w), bbox)]
                native_group = [w for w in group if w['method'] == 'native']
                suspected = [w for w in native_group if w['quality'] == 'suspect']
                needs_ocr = not native_group or bool(suspected)
                region_warnings, metadata = [], None
                method = 'native' if native_group else 'no-text'
                if suspected:
                    region_warnings.append('该区域存在局部乱码或私用钢筋字形，保留原文字，须核验图像')
                if needs_ocr:
                    if ocr:
                        try:
                            recognized, metadata = _ocr_region(path, index + 1, bbox)
                            for word in recognized:
                                if not any(w['text'] == word['text'] and _intersects(_word_box(w), _word_box(word)) for w in group):
                                    words.append(word)
                                    group.append(word)
                            method = 'native+ocr' if native_group else 'ocr'
                            region_warnings.append('OCR所得尺寸、钢筋符号需对照图像核验')
                            region_warnings.extend(metadata['limitations'])
                        except Exception as error:
                            region_warnings.append('OCR不可用或失败：' + type(error).__name__)
                    else:
                        region_warnings.append('该区域无可靠原生文字或存在局部乱码，尚未OCR')
                tables, table_warnings, table_status = _tables(p, bbox, box, sx, sy, rid)
                page_tables.extend(tables)
                region_warnings.extend(table_warnings)
                regions.append({'id': rid, 'bbox': bbox, 'text': '', 'wordIds': [], 'method': method,
                    'warnings': region_warnings, 'needsVisualReview': needs_ocr, 'tableDetection': table_status,
                    'tableIds': [t['id'] for t in tables], 'renderMetadata': metadata})
                page_warnings.extend(f'区域{tile_index + 1}：{message}' for message in region_warnings)
            for wi, word in enumerate(words):
                word['id'] = f'{digest[:16]}:p{index + 1}:w{wi}'
            for table in page_tables:
                table['wordIds'] = [w['id'] for w in words if _intersects(_word_box(w), table['bbox'])]
            for region in regions:
                group = sorted((w for w in words if _intersects(_word_box(w), region['bbox'])),
                               key=lambda w: (round(w['top'] / 3), w['x0']))
                region['wordIds'] = [w['id'] for w in group]
                region['text'] = ' '.join(w['text'] for w in group)
            text = ' '.join(w['text'] for w in words)
            if not words:
                page_warnings.append('无法提取可靠文字；完整图形区域仍已列入证据，不能视为已审核')
            indexes = candidate_indexes(words, page_tables, index + 1)
            methods = {w['method'] for w in words}
            method = 'native+ocr' if len(methods) > 1 else next(iter(methods), 'no-text')
            pages.append({'page': index + 1, 'width': width, 'height': height, 'rotation': p.rotation,
                'coordinateSystem': 'visible-page-top-left-pt', 'sourceVisibleBox': box,
                'text': text, 'words': words, 'regions': regions, 'lineCount': len(p.lines),
                'rectCount': len(p.rects), 'method': method, 'warnings': page_warnings,
                'drawingNumbers': list(dict.fromkeys(item['value'] for item in indexes['drawingNumbers'])),
                'candidateIndexes': indexes, 'coverage': {'mode': 'complete-spatial-tiles',
                    'tileSizePt': TILE_SIZE_PT, 'overlapPt': TILE_OVERLAP_PT,
                    'regionCount': len(regions), 'textIndependent': True}})
            warnings.extend(f'第{index + 1}页：{message}' for message in page_warnings)
            p.flush_cache()
    result = {'sha256': digest, 'extractorVersion': EXTRACTOR_VERSION, 'engineVersion': __version__,
              'pageCount': len(pages), 'pages': pages, 'warnings': warnings, 'cacheHit': False}
    atomic_json(target, result)
    return result
